
-- --------------------------------------------------------

--
-- Struktur dari tabel `kategori`
--

CREATE TABLE `kategori` (
  `id_kategori` int(11) NOT NULL,
  `id_parent` int(11) NOT NULL DEFAULT '0' COMMENT 'untuk mengatur sub kategori nantinya',
  `nama_kategori` varchar(25) NOT NULL,
  `deskripsi_kategori` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='menampung kategori';

--
-- Dumping data untuk tabel `kategori`
--

INSERT INTO `kategori` (`id_kategori`, `id_parent`, `nama_kategori`, `deskripsi_kategori`) VALUES
(5, 0, 'Food', 'Food'),
(7, 0, 'Drink', 'Drink');
