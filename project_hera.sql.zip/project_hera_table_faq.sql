
-- --------------------------------------------------------

--
-- Struktur dari tabel `faq`
--

CREATE TABLE `faq` (
  `id_faq` int(11) NOT NULL,
  `tanya_faq` varchar(140) NOT NULL,
  `jawab_faq` varchar(140) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `faq`
--

INSERT INTO `faq` (`id_faq`, `tanya_faq`, `jawab_faq`) VALUES
(2, 'Testing', 'Testing');
