
-- --------------------------------------------------------

--
-- Struktur dari tabel `pengaturan`
--

CREATE TABLE `pengaturan` (
  `id_pengaturan` int(11) NOT NULL,
  `nama_pengaturan` varchar(25) NOT NULL,
  `isi_pengaturan` varchar(140) NOT NULL,
  `deskripsi_pengaturan` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data untuk tabel `pengaturan`
--

INSERT INTO `pengaturan` (`id_pengaturan`, `nama_pengaturan`, `isi_pengaturan`, `deskripsi_pengaturan`, `created_at`, `updated_at`) VALUES
(2, 'aaaa', 'aaa', 'aaa', '2018-01-01 15:29:49', '2018-01-01 15:29:49');
